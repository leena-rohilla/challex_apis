<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\AccomplishmentsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\AccomplishmentsTable Test Case
 */
class AccomplishmentsTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\AccomplishmentsTable
     */
    public $Accomplishments;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.accomplishments',
        'app.users',
        'app.acc_tasks',
        'app.acc_help_categories'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('Accomplishments') ? [] : ['className' => 'App\Model\Table\AccomplishmentsTable'];
        $this->Accomplishments = TableRegistry::get('Accomplishments', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Accomplishments);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
