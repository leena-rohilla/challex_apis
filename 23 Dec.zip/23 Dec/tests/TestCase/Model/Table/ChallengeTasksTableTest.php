<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\ChallengeTasksTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\ChallengeTasksTable Test Case
 */
class ChallengeTasksTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\ChallengeTasksTable
     */
    public $ChallengeTasks;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.challenge_tasks'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('ChallengeTasks') ? [] : ['className' => 'App\Model\Table\ChallengeTasksTable'];
        $this->ChallengeTasks = TableRegistry::get('ChallengeTasks', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->ChallengeTasks);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
