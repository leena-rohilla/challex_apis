<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * AccomplishmentsFixture
 *
 */
class AccomplishmentsFixture extends TestFixture
{

    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'users_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'date' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'acc_tasks_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'acc_help_categories_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'description_text' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'timestamp', 'length' => null, 'null' => false, 'default' => 'CURRENT_TIMESTAMP', 'comment' => '', 'precision' => null],
        '_indexes' => [
            'accomplishment_ibfk_1' => ['type' => 'index', 'columns' => ['users_id'], 'length' => []],
            'accomplishments_ibfk_2' => ['type' => 'index', 'columns' => ['acc_tasks_id'], 'length' => []],
            'accomplishments_ibfk_3' => ['type' => 'index', 'columns' => ['acc_help_categories_id'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id'], 'length' => []],
            'accomplishments_ibfk_1' => ['type' => 'foreign', 'columns' => ['users_id'], 'references' => ['users', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'accomplishments_ibfk_2' => ['type' => 'foreign', 'columns' => ['acc_tasks_id'], 'references' => ['acc_tasks', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'accomplishments_ibfk_3' => ['type' => 'foreign', 'columns' => ['acc_help_categories_id'], 'references' => ['acc_help_categories', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd

    /**
     * Records
     *
     * @var array
     */
    public $records = [
        [
            'id' => 1,
            'users_id' => 1,
            'date' => '2016-08-05 04:19:40',
            'acc_tasks_id' => 1,
            'acc_help_categories_id' => 1,
            'description_text' => 'Lorem ipsum dolor sit amet',
            'created' => '2016-08-05 04:19:40',
            'modified' => 1470370780
        ],
    ];
}
