<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ChallengesFixture
 *
 */
class ChallengesFixture extends TestFixture
{

    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'users_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'date' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'challenges_tasks_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'challenges_sub_category_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'description_text' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'timestamp', 'length' => null, 'null' => false, 'default' => 'CURRENT_TIMESTAMP', 'comment' => '', 'precision' => null],
        '_indexes' => [
            'challenges_ibfk_1' => ['type' => 'index', 'columns' => ['users_id'], 'length' => []],
            'challenges_ibfk_2' => ['type' => 'index', 'columns' => ['challenges_tasks_id'], 'length' => []],
            'challenges_ibfk_3' => ['type' => 'index', 'columns' => ['challenges_sub_category_id'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id'], 'length' => []],
            'challenges_ibfk_1' => ['type' => 'foreign', 'columns' => ['users_id'], 'references' => ['users', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'challenges_ibfk_2' => ['type' => 'foreign', 'columns' => ['challenges_tasks_id'], 'references' => ['challenge_tasks', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'challenges_ibfk_3' => ['type' => 'foreign', 'columns' => ['challenges_sub_category_id'], 'references' => ['challenge_sub_categories', 'id'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd

    /**
     * Records
     *
     * @var array
     */
    public $records = [
        [
            'id' => 1,
            'users_id' => 1,
            'date' => '2016-08-05 04:19:40',
            'challenges_tasks_id' => 1,
            'challenges_sub_category_id' => 1,
            'description_text' => 'Lorem ipsum dolor sit amet',
            'created' => '2016-08-05 04:19:40',
            'modified' => 1470370780
        ],
    ];
}
