<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;
use Cake\Auth\DefaultPasswordHasher;

/**
 * Users Model
 *
 * @method \App\Model\Entity\User get($primaryKey, $options = [])
 * @method \App\Model\Entity\User newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\User[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\User|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\User patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\User[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\User findOrCreate($search, callable $callback = null)
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class UsersTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->table('users');
        $this->displayField('id');
        $this->primaryKey('id');

        $this->addBehavior('Timestamp');
        
        $this->hasMany('UserTokens', [
            'className' => 'UserTokensTable',
             'foreignKey' => 'users_id'
        ]);
        
        $this->hasMany('Follows', [
            'className' => 'FollowsTable',
             'foreignKey' => 'users_id'
        ]); 
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->requirePresence('first_name', 'create')
            ->notEmpty('first_name','Please provide First name.')
            ->add('first_name', [
                'maxLength' => [
                    'rule' => ['maxLength', 50],
                    'message' => 'First Name must be less than 50 characters!',
                ]
            ])
            ->add('first_name','custom',[
                'rule' => function($value){
                            if ($value) {
                                if (!preg_match("/^[a-zA-Z ]+$/i", $value)) {
                                    return false;
                                }
                            }
                    return true;
                },
                'message'=>'Only characters are allowed in First name.',
            ]);

        $validator
            ->requirePresence('last_name', 'create')
            ->notEmpty('last_name','Please provide Last Name.')
            ->add('last_name', [
                'maxLength' => [
                    'rule' => ['maxLength', 50],
                    'message' => 'Last Name must be less than 50 characters!',
                ]
            ])
            ->add('last_name','custom',[
                'rule' => function($value){
                            if ($value) {
                                if (!preg_match("/^[a-zA-Z ]+$/i", $value)) {
                                    return false;
                                }
                            }
                    return true;
                },
                'message'=>'Only characters are allowed in Last name.',
            ]);

        $validator
            ->email('email')
            ->requirePresence('email', 'create')
            ->notEmpty('email','Please provide email.');
		

        $validator
            ->requirePresence('password', 'create')
            ->notEmpty('password','Please provide password.')
            ->add('password', [
                'minLength' => [
                    'rule' => ['minLength', 6],
                    'message' => 'The password have to be at least 6 characters!',
                ]
            ]);
           /* ->add('password','custom',[
                'rule' => function($value){
                            if ($value) {
                                if (!preg_match('/(?=^.{8,}$)((?=.*\d)|(?=.*\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$/', $value)) {
                                    return false;
                                }
                            }
                    return true;
                },
                'message'=>'Password must be a minimum of 6 characters with at least one special character or numeric, at least one uppercase letter & at least one lower case letter.!',
            ]);*/

       
		$validator
            ->requirePresence('phone','create')
            ->allowEmpty('phone')
            ->add('phone', [
                'minLength' => [
                    'rule' => ['minLength', 10],
                    'last' => true,
                    'message' => 'Phone No length must be 10 numbers!.'
                ],
                'maxLength' => [
                    'rule' => ['maxLength', 10],
                    'message' => 'Phone No length must be 10 numbers!.',
                ]
            ])
            ->add('phone','custom',[
                'rule' => function($value){
                            if ($value) {
                                if (!preg_match("/^[0-9 ()-]+$/i", $value)) {
                                    return false;
                                }
                            }
                    return true;
                },
                'message'=> 'Invalid Phone Number',
            ]);
            
            
        $validator
            //->requirePresence('reset_pass_token', 'create')
            ->allowEmpty('reset_pass_token');

        return $validator;
    }

     /**
    *       Password Validations
    **/

    public function validationPassword(Validator $validator )
    {
        $validator
            ->add('new_password', [
                'length' => [
                    'rule' => ['minLength', 6],
                    'message' => 'The password have to be at least 6 characters!',
                ]
            ])
            
            ->notEmpty('new_password');
            
        $validator
            ->add('confirm_password', [
                'length' => [
                    'rule' => ['minLength', 6],
                    'message' => 'The password have to be at least 6 characters!',
                ]
            ])
            ->add('confirm_password',[
                'match'=>[
                    'rule'=> ['compareWith','new_password'],
                    'message'=>'The passwords does not match!',
                ]
            ])
            ->notEmpty('confirm_password');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['email'],'This email already exist.'));

        return $rules;
    }
}
