<?php
namespace App\Controller;

use App\Controller\AppController;
use Cake\Auth\DefaultPasswordHasher;
 use Cake\Mailer\Email;
use Cake\Routing\Router;

/**
*   Api Controller
**/
class ApiController extends AppController
{
    public function initialize(){
        parent::initialize();  
    
    }

    public function beforeFilter(\Cake\Event\Event $event){
        $this->Auth->allow(['index','register','login','forgotPassword','resetPassword','getMyProfile','getCatregories','getMyChannels','getMyChallenges','getChannels','getChallenges','updateProfile','changePassword']);
    }

    public function index(){
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;
        $result = [];
        $finalresult['status'] = 0;
        $finalresult['message'] = "You don't have sufficient privilages to access this page";
        $finalresult['response'] = "";        
        $result['NO_ACCESS'] = $finalresult;
        echo json_encode($result);  
        exit;
    }

    /**
     * Register method
     *
     * @return \Cake\Network\Response|void Redirects on successful add, renders view otherwise.
     */
    public function register(){
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;
        $result = [];
        
        if($this->request->is('post')) {
			
            $json = file_get_contents('php://input');
            $jsonData = json_decode($json, true);
            $this->request->data = $jsonData;
			
			$insertUserData['first_name']= @$this->request->data['first_name'];
			$insertUserData['last_name']= @$this->request->data['last_name'];
			$insertUserData['username']= @$this->request->data['username'];
			$insertUserData['email']= @$this->request->data['email'];
			$insertUserData['password']= @$this->request->data['password'];
			$insertUserData['phone']= @$this->request->data['phone'];
			$insertUserData['access_token']= @$this->request->data['access_token'];
			$insertUserData['device_token']= @$this->request->data['device_token'];
			$insertUserData['device_type']= @$this->request->data['device_type'];
			
			if(@$this->request->data['login_type']== 2){
				$insertUserData['first_name']="testing";
				$insertUserData['last_name']="undefined";
				$insertUserData['username']=$this->request->data['username'];
				$insertUserData['email']=$this->request->data['email'];
				$insertUserData['password']="undefined";
				$insertUserData['phone']="0123456789";
				$insertUserData['access_token']="undefined";
				$insertUserData['device_token']="undefined";
				$insertUserData['device_type']="undefined";
				
			}
			
            $this->loadModel('Users');
			$user = $this->Users->newEntity();
			$user = $this->Users->patchEntity($user,$insertUserData);
			
			if ($result= $this->Users->save($user)) {
				$lastInsertId =$result->id;
				$user_id['user_id'] = $lastInsertId;
				
				$this->loadModel('UserTokens');
				$data['users_id'] = $result->id;
				$data['access_token'] = @$jsonData['access_token'];
				$data['device_token'] = @$jsonData['device_token'];
				$data['device_type'] = @$jsonData['device_type'];
				//pr($data); die;
				$usertoken = $this->UserTokens->newEntity();
				$usertoken = $this->UserTokens->patchEntity($usertoken, $data);
				$this->UserTokens->save($usertoken);
				
				$finalresult['status'] = 200;
				$finalresult['message'] = "Success";
				//$finalresult['response'] = $user_id; 
				echo json_encode($finalresult);  
				
			} else {
				$errors = $user->errors();
				foreach($errors as $key=>$value){
					foreach($value as $keytwo=>$message){
						echo $errorData[$key] = $message."<br />";
					}
				}

				$finalresult['status'] = 0;
				$finalresult['message'] = $message;
				//$finalresult['response'] = ""; 
				echo json_encode($finalresult);  
			}
            
        }

    } //EOF

    /**
    *   Login Method
    **/
    public function login(){
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;
        
        if($this->request->is('post')) {
            $json = file_get_contents('php://input');
            $jsonData = json_decode($json, true);
            $this->request->data = $jsonData;
            
			if($this->request->data['login_type']== 1){	
				if($this->request->data['email']==""){
					$finalresult['status'] = 0;
					$finalresult['message'] = "Please provide a valid email address.";
					$finalresult['response'] = "";
					echo json_encode($finalresult);   
				}
				if($this->request->data['password'] == ""){
					$finalresult['status'] = 0;
					$finalresult['message'] = "Please provide a password.";
					$finalresult['response'] = "";
					echo json_encode($finalresult);   
				}
				
			}else{
				if($this->request->data['email']==""){
					$finalresult['status'] = 0;
					$finalresult['message'] = "Please provide a valid email address.";
					$finalresult['response'] = "";
					echo json_encode($finalresult);   
				}
				if($this->request->data['username']==""){
					$finalresult['status'] = 0;
					$finalresult['message'] = "Please provide username.";
					$finalresult['response'] = "";
					echo json_encode($finalresult);   
				}
			}
			
            if($this->request->data['email']!="" && $this->request->data['password']!="" ){
				
				$userTable = $this->loadModel('Users');
                $user = $this->Auth->identify();
				
                if($user){
					
                    $this->Auth->setUser($user);
                    $userTokenTable = $this->loadModel('UserTokens');
                    $userTokens = $userTable->find('all',[
                    'conditions' => ['id' => $user['id']]])->contain(['UserTokens'])->toArray();
                    
                    $userTokens = $userTokens[0]->user_tokens;
                    //pr($userTokens[0]->device_token); die;
                    //$user_id['user_id'] =  $user['id'];
                    $finalresult['status'] = 200;
                    $finalresult['message'] = "Success";
                    $finalresult['userid'] = $user['id'];
                    $finalresult['first_name'] = $user['first_name'];
                    $finalresult['last_name'] = $user['last_name'];
                    $finalresult['username'] = $user['username'];
                    $finalresult['email'] = $user['email'];
                    $finalresult['phone'] = $user['phone'];
                    $finalresult['password'] = $this->request->data['password'];
                    $finalresult['device_token'] = $userTokens[0]->device_token;
                    echo json_encode($finalresult);   
                }else{
                    $finalresult['status'] = 0;
                    $finalresult['message'] = "Your email or password is incorrect.";
                    $finalresult['response'] = "";
                    echo json_encode($finalresult);   
                }
            }elseif($this->request->data['email']!="" && $this->request->data['username']!=""){
					
					$email = $this->request->data['email'];
					$username = $this->request->data['username'];
					$userTable = $this->loadModel('Users');
					//$query = $userTable->find('all',['conditions' => ['username'=>$username,'email' => $email]])->count();
					$query = $userTable->find('all',['conditions' => ['email' => $email]])->count();
					
					if($query == 1) { // login if email and username both exists
						
						$userTable = $this->loadModel('Users');
						$userData = $userTable->find('all',['conditions' => ['email' => $email]])->first();
						
						$userTokenTable = $this->loadModel('UserTokens');
						$userTokens = $userTable->find('all',[
						'conditions' => ['id' => $userData['id']]])->contain(['UserTokens'])->toArray();
						$userTokens = $userTokens[0]->user_tokens;
						
						$finalresult['status'] = 200;
						$finalresult['message'] = "Success";
						$finalresult['userid'] = $userData['id'];
						$finalresult['first_name'] = $userData['first_name'];
						$finalresult['last_name'] = $userData['last_name'];
						$finalresult['username'] = $userData['username'];
						$finalresult['email'] = $userData['email'];
						$finalresult['phone'] = $userData['phone'];
						$finalresult['device_token'] = $userTokens[0]->device_token;
						echo json_encode($finalresult);   
						
					}elseif($query == 0){ // register if email does not exits
					 
						$this->register($this->request->data);
						
						
					}else{ // Login fialed	
						$finalresult['status'] = 0;
						$finalresult['message'] = "Your email or username is incorrect.";
						$finalresult['response'] = "";
						echo json_encode($finalresult);   
					}
			}
        }

    } //EOF

    /**
    *   Forgot Password Method.
    **/

    public function forgotPassword() {
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;
        $result = [];
        if($this->request->is('post')) {

            $json = file_get_contents('php://input');
            $jsonData = json_decode($json, true);
            $this->request->data = $jsonData;

            $email = $this->request->data['email'];
            $userTable =  $this->loadModel('Users');
            
            $exists = $userTable->exists(['email' => $email]);
            if($exists){
                $getUserId = $userTable->find('all',['conditions' => ['email' => $email]])->Select(['id'])->first();
               //echo $getUserId->id; die;
			
               $token = bin2hex(openssl_random_pseudo_bytes(16));
			   $userTokenTable = $this->loadModel('UserTokens');
               //pr($token); die;
               $url = Router::url(array("controller"=>"api","action"=>"resetPassword/".$token),true); 
               //pr($url); die;
               $updateHits=  $userTable->query()
                                      ->update()
                                      ->set(['reset_pass_token' =>  $token])
                                      ->where(['id' => $getUserId->id])
                                      ->execute();

               // pr($updateHits); die;
                if ($updateHits) {
                   $to = $email;
                   $emailObj = new Email();
                   $emailObj->from(['trantor.php@gmail.com' => 'Challex'])
                        ->to($to)
                        ->subject('Challex:ForgotPassword')
                        ->send('Please click here given link below to reset new password '. $url);
                    $finalresult['status'] = 1;
                    $finalresult['message'] = "Success";
                    $finalresult['response'] = "Email Sent.";
                    echo json_encode($finalresult);
                }else{
                    $finalresult['status'] = 0;
                    $finalresult['message'] = "Email does not send";
                    $finalresult['response'] = "";
                    echo json_encode($finalresult);
                }

                    
            }else{
                $finalresult['status'] = 0;
                $finalresult['message'] = "Email does not exists.";
                $finalresult['response'] = "";
                echo json_encode($finalresult); 

            }
        }

    } // EOF

	/**
    *   Reset Password Link
    *
    **/

    public function resetPassword() {
		
		$this->viewBuilder()->layout(false);
        /* $this->autoRender = false;*/
      
		$token_id = $this->request->params['pass'][0];
		$userTable = $this->loadModel('Users');
        $getUserId = $userTable->find('all',['conditions' => ['reset_pass_token' => $token_id]])->Select(['id'])->first();
        if(!empty($getUserId)){

        $user_id = $getUserId->id;
        $user =$userTable->get($user_id);
        
            if (!empty($this->request->data)) {
				$user = $userTable->patchEntity($user, [
                        'password'      => $this->request->data['new_password'],
                        'new_password'     => $this->request->data['new_password'],
                        'confirm_password'     => $this->request->data['confirm_password']
                    ],
                      ['validate' => 'password']
                );
                if ($this->Users->save($user)) {
					$updateToken =  $userTable->query()
                                      ->update()
                                      ->set(['reset_pass_token' =>  ""])
                                      ->where(['id' => $user_id])
                                      ->execute();
                    //pr($updateToken); die;
                    //$this->Flash->success('The password is successfully changed');
                    die('The password is successfully changed');
                    //$this->redirect(['controller' => 'api','action'=>'passwordChanged']);
                } else {
                    $this->Flash->error('There was an error during the save!');
                }
            }
             $this->set('user',$user);
        }else{

            echo 'Invalid token';
        }       

    } //EOF
    
    /**
    *   Get User Profile
    **/
    
    public function getMyProfile(){
		
		$this->viewBuilder()->layout(false);
        $this->autoRender = false;
        //$result = [];
        
        if($this->request->is('get')) {
			$user_id = $_GET['user_id'];

            if($user_id != ""){
				
				$userTable = $this->loadModel('Users');
				$userData = $userTable->find('all',['conditions' => ['id' => $user_id]])->first();
				
				/* Followers count*/
				$followTable = $this->loadModel('Follows');
				$followers_count = $followTable->find('all',['conditions' => ['users_id' => $user_id]])->count();
				
				/* Followed count*/
				$followed_count = $followTable->find('all',['conditions' => ['follower_user_id' => $user_id]])->count();
				
				/* Challenge post count*/
				$challengeTable = $this->loadModel('Challenges');
				$post_count = $challengeTable->find('all',['conditions' => ['users_id' => $user_id]])->count();
				
				if(isset($userData)) { 
					
					$finalresult['status'] = 200;
					$finalresult['message'] = "Success";
					//$finalresult['user_id'] = $userData['id'];
					//$finalresult['username'] = $userData['username'];
					$finalresult['followers'] = $followers_count;
					$finalresult['followed'] = $followed_count;
					$finalresult['posts'] = $post_count;
					$finalresult['bio'] = $userData['bio'];
					$finalresult['gender'] = $userData['gender'];
					$finalresult['profile_image'] = Router::url('/', true).'img/uploads/userImages/'.$userData['user_image'];
					echo json_encode($finalresult);    
					
				}else{
					$finalresult['status'] = 0;
					$finalresult['message'] = "No record found.";
					$finalresult['response'] = "";
					echo json_encode($finalresult);     
				} 
            }else{
                $finalresult['status'] = 0;
                $finalresult['message'] = "User id not found.";
                $finalresult['response'] = "";
                echo json_encode($finalresult);  
            }

        }
	}
	
    
    //EOF
    
    /**
    *   Get Categories list method
    **/
    public function getCatregories(){
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;
        //$result = [];
        
        if($this->request->is('get')) {
			$user_id = $_GET['user_id'];

            if($user_id != ""){
				$categoriesTable = $this->loadModel('Categories');
                $dataArray = $categoriesTable->find('all');
				$newCategoriesArray = array();
                    
                    foreach ($dataArray as $key=>$data) {
						$newCategoriesArray[$key]['category_id'] = $data['id'];
                        $newCategoriesArray[$key]['category_name'] = $data['name'];
                        
                    }
                    if(count($newCategoriesArray) > 1){
                        $finalresult['status'] = 200;
                        $finalresult['message'] = "Success";
                        //$result['Acc_tasks'] = $newAccTasksArray;
                        $finalresult['response'] = $newCategoriesArray; 
                        echo json_encode($finalresult);  
                    }else{
                        $finalresult['status'] = 0;
                        $finalresult['message'] = "No record found.";
                        $finalresult['response'] = "";
                        echo json_encode($finalresult);     
                    } 
            }else{
                $finalresult['status'] = 0;
                $finalresult['message'] = "User id not found.";
                $finalresult['response'] = "";
                echo json_encode($finalresult);  
            }


        }

    } //EOF
	
	/**
    *   Get My Channels list method
    **/
    public function getMyChannels(){
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;
        //$result = [];
        
        if($this->request->is('get')) {
			$user_id = $_GET['user_id'];
			 	
            if($user_id != ""){
				$categoriesTable = $this->loadModel('Channels');
                $dataArray = $categoriesTable->find('all',['conditions' => ['users_id' => $user_id]])->toArray();
                
				$newChannelsArray = array();
                    
                    foreach ($dataArray as $key=>$data) {
						
						/* Followers count*/
						$followTable = $this->loadModel('Follows');
						$channel_followers_count = $followTable->find('all',['conditions' => ['users_id'=>$user_id,'channels_id' => $data['id']]])->count();
						/*Ends */
						$newChannelsArray[$key]['channel_title'] = $data['chn_title'];
						$newChannelsArray[$key]['channel_id'] = $data['id'];
						$newChannelsArray[$key]['channel_image'] = Router::url('/', true).'img/uploads/channelImg/'.$data['chn_image'];
						$newChannelsArray[$key]['channel_description'] = $data['chn_description'];
						$newChannelsArray[$key]['channel_followers'] = $channel_followers_count;
						$newChannelsArray[$key]['view_count'] = ""; 
                    }
                    
                    if(count($newChannelsArray) > 1){
                        $finalresult['response'] = $newChannelsArray; 
                        $finalresult['status'] = 200;
                        $finalresult['message'] = "Success";
                        //$result['Acc_tasks'] = $newAccTasksArray;
                        echo json_encode($finalresult);  
                    }else{
                        $finalresult['status'] = 0;
                        $finalresult['message'] = "No record found.";
                        $finalresult['response'] = "";
                        echo json_encode($finalresult);     
                    } 
            }else{
                $finalresult['status'] = 0;
                $finalresult['message'] = "User id not found.";
                $finalresult['response'] = "";
                echo json_encode($finalresult);  
            }


        }

    } //EOF
    
        
    /**
    *   Get My Challenges list method
    **/
    public function getMyChallenges(){
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;
        //$result = [];
        
        if($this->request->is('get')) {
			$user_id = $_GET['user_id'];
			 	
            if($user_id != ""){
				$challengesTable = $this->loadModel('Challenges');
                $dataArray = $challengesTable->find('all',['conditions' => ['users_id' => $user_id]])->toArray();
               
				$newChallengesArray = array();
                    
                    foreach ($dataArray as $key=>$data) {
						
						/* Likes count*/
						$followTable = $this->loadModel('Likes');
						$channel_followers_count = $followTable->find('all',['conditions' => ['users_id'=>$user_id,'challenges_id' =>$data['id']]])->count();
						/*Ends */
						
						//pr(date('Y/m/d',$data['ch_date']->toDateTimeString()));
						$ch_date =  date_format(date_create($data['ch_date']->toDateTimeString()), 'Y-m-d');
						$newChallengesArray[$key]['challenge_title'] = $data['ch_title'];
						$newChallengesArray[$key]['challenge_id'] = $data['id'];
						$newChallengesArray[$key]['challenge_image'] = Router::url('/', true).'img/uploads/channelImg/'.$data['ch_image'];
						$newChallengesArray[$key]['challenge_description'] = $data['ch_description'];
						$newChallengesArray[$key]['challenge_likes'] = $channel_followers_count;
						$newChallengesArray[$key]['view_count'] = ""; 
						$newChallengesArray[$key]['challenge_category'] = $data['ch_category'];
						$newChallengesArray[$key]['posted_date'] = $ch_date; 
                    }
                    if(count($newChallengesArray) > 1){
                        $finalresult['response'] = $newChallengesArray; 
                        $finalresult['status'] = 200;
                        $finalresult['message'] = "Success";
                        //$result['Acc_tasks'] = $newAccTasksArray;
                        echo json_encode($finalresult);  
                    }else{
                        $finalresult['status'] = 0;
                        $finalresult['message'] = "No record found.";
                        $finalresult['response'] = "";
                        echo json_encode($finalresult);     
                    } 
            }else{
                $finalresult['status'] = 0;
                $finalresult['message'] = "User id not found.";
                $finalresult['response'] = "";
                echo json_encode($finalresult);  
            }


        }

    } //EOF
  
	/**
    *   Get All Channels list method
    **/
    public function getChannels(){
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;
        //$result = [];
        
        if($this->request->is('get')) {
			$user_id = $_GET['user_id'];
			 	
            if($user_id != ""){
				$categoriesTable = $this->loadModel('Channels');
                $dataArray = $categoriesTable->find('all')->toArray();
                
				$newChannelsArray = array();
                    
                    foreach ($dataArray as $key=>$data) {
						
						/* Followers count*/
						$followTable = $this->loadModel('Follows');
						$channel_followers_count = $followTable->find('all',['conditions' => ['channels_id' => $data['id']]])->count();
						/*Ends */
						$newChannelsArray[$key]['channel_title'] = $data['chn_title'];
						$newChannelsArray[$key]['channel_id'] = $data['id'];
						$newChannelsArray[$key]['channel_image'] = Router::url('/', true).'img/uploads/channelImg/'.$data['chn_image'];
						$newChannelsArray[$key]['channel_description'] = $data['chn_description'];
						$newChannelsArray[$key]['channel_followers'] = $channel_followers_count;
						$newChannelsArray[$key]['view_count'] = ""; 
                    }
                    
                    if(count($newChannelsArray) > 1){
                        $finalresult['response'] = $newChannelsArray; 
                        $finalresult['status'] = 200;
                        $finalresult['message'] = "Success";
                        //$result['Acc_tasks'] = $newAccTasksArray;
                        echo json_encode($finalresult);  
                    }else{
                        $finalresult['status'] = 0;
                        $finalresult['message'] = "No record found.";
                        $finalresult['response'] = "";
                        echo json_encode($finalresult);     
                    } 
            }else{
                $finalresult['status'] = 0;
                $finalresult['message'] = "User id not found.";
                $finalresult['response'] = "";
                echo json_encode($finalresult);  
            }


        }

    } //EOF
    
            
    /**
    *   Get All Challenges list method
    **/
    public function getChallenges(){
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;
        //$result = [];
        
        if($this->request->is('get')) {
			$user_id = $_GET['user_id'];
			 	
            if($user_id != ""){  echo Router::url('/', true);
				$challengesTable = $this->loadModel('Challenges');
                $dataArray = $challengesTable->find('all')->toArray();
               
				$newChallengesArray = array();
                    
                    foreach ($dataArray as $key=>$data) {
						
						/* Likes count*/
						$followTable = $this->loadModel('Likes');
						$channel_followers_count = $followTable->find('all',['conditions' => ['challenges_id' =>$data['id']]])->count();
						/*Ends */
						
						//pr(date('Y/m/d',$data['ch_date']->toDateTimeString()));
						$ch_date =  date_format(date_create($data['ch_date']->toDateTimeString()), 'Y-m-d');
						$newChallengesArray[$key]['challenge_title'] = $data['ch_title'];
						$newChallengesArray[$key]['challenge_id'] = $data['id'];
						$newChallengesArray[$key]['challenge_image'] = Router::url('/', true).'img/uploads/channelImg/'.$data['ch_image'];
						$newChallengesArray[$key]['challenge_description'] = $data['ch_description'];
						$newChallengesArray[$key]['challenge_likes'] = $channel_followers_count;
						$newChallengesArray[$key]['view_count'] = ""; 
						$newChallengesArray[$key]['challenge_category'] = $data['ch_category'];
						$newChallengesArray[$key]['posted_date'] = $ch_date; 
                    }
                    if(count($newChallengesArray) > 1){
                        $finalresult['response'] = $newChallengesArray; 
                        $finalresult['status'] = 200;
                        $finalresult['message'] = "Success";
                        //$result['Acc_tasks'] = $newAccTasksArray;
                        echo json_encode($finalresult);  
                    }else{
                        $finalresult['status'] = 0;
                        $finalresult['message'] = "No record found.";
                        $finalresult['response'] = "";
                        echo json_encode($finalresult);     
                    } 
            }else{
                $finalresult['status'] = 0;
                $finalresult['message'] = "User id not found.";
                $finalresult['response'] = "";
                echo json_encode($finalresult);  
            }


        }

    } //EOF
    
    /**
    *   Update user profile
    **/
    public function updateProfile(){
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;
        $result = [];
        $user_result = [];
        if($this->request->is('post')) {
			
            $json = file_get_contents('php://input');
            $jsonData = json_decode($json, true); 
            $this->request->data = $jsonData;
            
            $userTable = $this->loadModel('Users');
            $exists = $userTable->exists(['id' => $this->request->data['user_id']]);
            if($exists){
				
				$user_image = $this->request->data['user_image'];
				if(isset($user_image) && !empty($user_image)) { 
					$fileActualName = time() . "_" . rand(000000, 999999);
					$fileActualName = $fileActualName . '.png';
					
					$uploaded_image = $this->base64_to_jpeg($jsonData['user_image'],WWW_ROOT.'img/uploads/userImages/'.$fileActualName);
					$this->request->data['user_image'] = $fileActualName;
				}
				
				$user =$userTable->get($this->request->data['user_id']); 
				$user = $userTable->patchEntity($user, $this->request->data);
				$user->id = $this->request->data['user_id'];
				if ($result= $userTable->save($user)) {	
						$user_id['user_id'] = $this->request->data['user_id'];
						$user_id['first_name'] = $this->request->data['first_name'];
						$user_id['last_name'] = $this->request->data['last_name'];
						$user_id['username'] = $this->request->data['first_name'].' '.$this->request->data['last_name'];
						$user_id['phone'] = $this->request->data['phone'];
						$user_id['bio'] = $this->request->data['bio'];
						
						if(!empty($this->request->data['user_image'])) {
							$user_id['user_image'] = Router::url('/', true).'img/uploads/userImages/'.$this->request->data['user_image'];
						} else {
							$user_id['user_image'] ="";
						}
						
						$finalresult['status'] = 200;
						$finalresult['message'] = "Successfully updated";
						$finalresult['response'] = $user_id;
						echo json_encode($finalresult); 
						
				}
				else {
						$errors = $user->errors();
						foreach($errors as $key=>$value){
							foreach($value as $keytwo=>$message){
								$errorData[$key] = $message;
							}
						}
						$finalresult['status'] = 0;
						$finalresult['message'] = $message;
						$finalresult['response'] = new \stdClass();
						echo json_encode($finalresult); 
				}
				
			}
			else {
				$finalresult['status'] = 0;
                $finalresult['message'] = "User doesn't exist.";
                $finalresult['response'] = new \stdClass();
                echo json_encode($finalresult); 
			}
           
        }

    }//EOF
    
    /**
    *   Change Password
    **/
	public function changePassword(){
        $this->viewBuilder()->layout(false);
        $this->autoRender = false;

        if($this->request->is('post')) {
			
            $json = file_get_contents('php://input');
            $jsonData = json_decode($json, true);
            $this->request->data = $jsonData;
            
            if($this->request->data['new_password']==""){
                $finalresult['status'] = 0;
                $finalresult['message'] = "Please provide new password.";
                echo json_encode($finalresult);   
            }
	
            $userTable = $this->loadModel('Users');
            $exists = $userTable->exists(['id' => $this->request->data['user_id']]);
            
            if($exists){
				$user =$userTable->get($this->request->data['user_id']); 
				$user = $userTable->patchEntity($user, $this->request->data);
				$user->id = $this->request->data['user_id'];
				$user->password = $this->request->data['new_password'];
				if ($result= $userTable->save($user)) {	
					$finalresult['status'] = 200;
					$finalresult['message'] = "Successfully updated";
					$finalresult['response'] = $this->request->data['user_id'];
					echo json_encode($finalresult); 
				}
				
			}
			else {
				$finalresult['status'] = 0;
                $finalresult['message'] = "User doesn't exist.";
                $finalresult['response'] = new \stdClass();
                echo json_encode($finalresult); 
			}	
		}
	}//EOF		

	
} //EOC
